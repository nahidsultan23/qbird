self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "cc386d22b0c77dfdaaf0b88c61b2fcd9",
    "url": "/index.html"
  },
  {
    "revision": "98a7831c5ce460e7b9d2",
    "url": "/static/css/2.2c8c8cbb.chunk.css"
  },
  {
    "revision": "98a7831c5ce460e7b9d2",
    "url": "/static/js/2.1958efdf.chunk.js"
  },
  {
    "revision": "a77de97043ede721e98de468a773f257",
    "url": "/static/js/2.1958efdf.chunk.js.LICENSE.txt"
  },
  {
    "revision": "271f0343bd08c4c60494",
    "url": "/static/js/main.2793a7e8.chunk.js"
  },
  {
    "revision": "9b4e396c183e42c1fa5c",
    "url": "/static/js/runtime-main.09b85ec0.js"
  },
  {
    "revision": "93755b050671de7b2ed7b269e6fa0be0",
    "url": "/static/media/noPhotoAvailable640x600.93755b05.png"
  },
  {
    "revision": "df39e77f2cf3fb2f23d54082f681a2ca",
    "url": "/static/media/person-avatar.df39e77f.png"
  },
  {
    "revision": "7339b8dc2b29307473785f467fb96dc3",
    "url": "/static/media/searching-delivery-person.7339b8dc.gif"
  }
]);